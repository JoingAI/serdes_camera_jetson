#!/bin/sh
# FG12/FG24-4CH x D457/D585 upgrade package v2 (JetPack 7.2.1 / R39.2.1, 6.8.12-1021-tegra)
# v2: 增加 nvhost-nvcsi/vi5/capture/isp5/pva/nvdla —— 必须与 tegra-camera.ko 同批构建，
#     否则重刷系统后会出现 "disagrees about version of symbol csi5_fops"、无 /dev/video*。
set -e
BOARD=""; CAMERA=""; BOOT=/boot
while [ $# -gt 0 ]; do case "$1" in --board) BOARD=$2;shift 2;; --camera) CAMERA=$2;shift 2;; *) shift;; esac; done
HERE=$(cd $(dirname $0) && pwd); KREL=$(uname -r); U=/lib/modules/$KREL/updates
[ "$(id -u)" = 0 ] || { echo "sudo required"; exit 1; }
i2c_rd(){ i2ctransfer -y $1 w2@$2 $3 $4 r1 2>/dev/null | tail -1; }
[ -n "$BOARD" ] || for b in /dev/i2c-*; do
  bus=${b#/dev/i2c-}; v=$(echo "$(i2c_rd $bus 0x27 0x00 0x00)"|tr A-F a-f)
  [ "$v" = 0x4e ] && { BOARD=fg24; break; }
  v=$(echo "$(i2c_rd $bus 0x29 0x00 0x00)"|tr A-F a-f)
  [ "$v" = 0x4e ] && { BOARD=fg12; break; }
done
[ -n "$CAMERA" ] || for b in /dev/i2c-*; do
  bus=${b#/dev/i2c-}; for a in 0x40 0x41; do
    v=$(echo "$(i2c_rd $bus $a 0x00 0x0d)"|tr A-F a-f)
    [ "$v" = 0xbf ] && { CAMERA=d585; break 2; }
    [ "$v" = 0x91 ] && { CAMERA=d457; break 2; }
  done
done
[ -n "$BOARD" ] || BOARD=fg24; [ -n "$CAMERA" ] || CAMERA=d457
echo "[install] $BOARD + $CAMERA"
case "$BOARD$CAMERA" in
  fg24d585) D=tegra234-camera-d4xx-overlay-fg24-4ch-d5xx.dtbo; L=fg24d585;;
  fg24d457) D=tegra234-camera-d4xx-overlay-fg24-4ch.dtbo; L=fg24d457;;
  fg12d585) D=tegra234-camera-d4xx-overlay-fg12-4ch-d5xx.dtbo; L=fg12d585;;
  *) D=tegra234-camera-d4xx-overlay-fg12-4ch.dtbo; L=fg12d457;;
esac
mkdir -p $U
# 整体覆盖 updates（含 i2c / platform / video-host 全套）
cp -a $HERE/lib/modules/$KREL/updates/. $U/
cp -a $HERE/boot/*.dtbo $BOOT/
depmod -a $KREL
systemctl disable --now fzcam_cfg.service 2>/dev/null || true
CONF=$BOOT/extlinux/extlinux.conf
FDT=$(awk '/^[[:space:]]*FDT /{print $2; exit}' $CONF)
APPEND=$(awk '/^[[:space:]]*APPEND /{sub(/^[[:space:]]*APPEND /,"");print; exit}' $CONF)
add(){ grep -q "^LABEL $1" $CONF && return 0; cat >> $CONF <<EOC

LABEL $1
	MENU LABEL RealSense $3
	LINUX /boot/Image
	FDT $FDT
	INITRD /boot/initrd
	APPEND $APPEND
	OVERLAYS /boot/$2
EOC
}
add fg12d585 tegra234-camera-d4xx-overlay-fg12-4ch-d5xx.dtbo "D585 FG12-4CH"
add fg12d457 tegra234-camera-d4xx-overlay-fg12-4ch.dtbo "D457 FG12-4CH"
add fg24d585 tegra234-camera-d4xx-overlay-fg24-4ch-d5xx.dtbo "D585 FG24-4CH"
add fg24d457 tegra234-camera-d4xx-overlay-fg24-4ch.dtbo "D457 FG24-4CH"
sed -i "s/^DEFAULT .*/DEFAULT $L/" $CONF
echo "[install] DEFAULT=$L done, reboot"
echo "[install] modules:"; ls $U/drivers/video/tegra/host/*/*.ko 2>/dev/null | wc -l
