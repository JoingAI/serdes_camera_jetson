#!/bin/sh
# librealsense 2.59.1 离线/弱网编译脚本（Jetson Orin NX, JetPack 7.2.1 / R39.2.1）
# 用法：sudo sh lrs_build_offline.sh /path/to/librealsense-src
# 背景：重刷系统后 1) 缺 glfw/gtk/nlohmann 依赖 2) 无外网时 CMake 拉 json/curl 失败
set -e
SRC=${1:-/home/nvidia/lrs2591}
[ -f "$SRC/CMakeLists.txt" ] || { echo "usage: $0 <librealsense source dir>"; exit 1; }

echo "== 1. 安装依赖"
DEBIAN_FRONTEND=noninteractive apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
  git libssl-dev libusb-1.0-0-dev libudev-dev pkg-config \
  libgtk-3-dev mesa-common-dev libgl1-mesa-dev libglu1-mesa-dev libglfw3-dev \
  nlohmann-json3-dev build-essential cmake

echo "== 2. 用系统 nlohmann 头，绕过 GitHub 下载"
mkdir -p "$SRC/build/third-party/json/include"
cp -a /usr/include/nlohmann "$SRC/build/third-party/json/include/"
python3 - "$SRC" <<'PY'
import sys
p=sys.argv[1]+"/CMake/external_json.cmake"
s=open(p).read()
guard='''function(get_nlohmann_json)

    # Patched: offline build - use system nlohmann headers
    if(EXISTS "${CMAKE_BINARY_DIR}/third-party/json/include/nlohmann/json.hpp")
        message( STATUS "Using pre-staged nlohmann/json headers (offline)" )
        return()
    endif()
'''
old="function(get_nlohmann_json)\n"
if "offline build - use system nlohmann" not in s:
    assert old in s
    open(p,"w").write(s.replace(old,guard,1))
    print("json patch applied")
else:
    print("json patch already applied")
PY

echo "== 3. 配置（关闭需联网克隆 curl 的 viewer 特性）"
rm -rf "$SRC/build/third-party/libcurl" "$SRC/build/libcurl"
cd "$SRC/build"
export PATH=$PATH:/usr/local/cuda/bin
cmake .. -DBUILD_EXAMPLES=true -DCMAKE_BUILD_TYPE=release \
  -DFORCE_RSUSB_BACKEND=false -DBUILD_WITH_CUDA=true \
  -DCMAKE_CUDA_COMPILER=/usr/local/cuda/bin/nvcc \
  -DCHECK_FOR_UPDATES=OFF -DENABLE_AI_ASSISTANT=OFF -DENABLE_STATS=OFF

echo "== 4. 编译安装"
make -j$(($(nproc)-1))
make install && ldconfig

echo "== 5. 安装 udev 规则并生成 /dev/video-rs-* 链接"
cp -f "$SRC"/config/99-realsense-libusb.rules "$SRC"/config/99-realsense-d4xx-mipi-dfu.rules /etc/udev/rules.d/ 2>/dev/null || true
cp -f "$SRC"/scripts/rs-enum.sh "$SRC"/scripts/rs_ipu6_d457_bind.sh /usr/local/bin/ 2>/dev/null || true
chmod +x /usr/local/bin/rs-enum.sh 2>/dev/null || true
udevadm control --reload-rules; udevadm trigger
/usr/local/bin/rs-enum.sh || true
echo "== done: rs-enumerate-devices 验证"
rs-enumerate-devices 2>&1 | head -8
