#!/bin/bash
# =============================================================================
# FangZhu FG12-4CH / FG24-4CH  x  RealSense D585 / D457  一键升级包
# 适用: Jetson Orin NX / Orin Nano Devkit (p3768-0000 + p3767-xxxx)
#       JetPack 6.2.2 / L4T R36.5 / 内核 5.15.185-tegra
# 用法: sudo ./install.sh [--board fg12|fg24] [--camera d585|d457] [--boot /boot]
#       不带参数时自动识别（识别不到则默认 fg12+d585，并给出提示）
# =============================================================================
set -euo pipefail

BOARD=""; CAMERA=""; BOOT="/boot"
while [ $# -gt 0 ]; do
  case "$1" in
    --board)  BOARD="${2:-}"; shift 2 ;;
    --camera) CAMERA="${2:-}"; shift 2 ;;
    --boot)   BOOT="${2:-/boot}"; shift 2 ;;
    -h|--help) sed -n '2,9p' "$0"; exit 0 ;;
    *) echo "未知参数: $1"; exit 1 ;;
  esac
done

HERE="$(cd "$(dirname "$0")" && pwd)"
KREL="$(uname -r)"
DEST="/lib/modules/$KREL/updates"
STAMP="$(date +%Y%m%d-%H%M%S)"
log(){ echo "[install] $*"; }

# ---------- 1. 环境检查 ----------
[ "$(id -u)" = "0" ] || { echo "请用 sudo 运行"; exit 1; }
[ -d "$BOOT" ] || { echo "找不到 $BOOT"; exit 1; }
log "内核: $KREL"
case "$KREL" in
  5.15.185-tegra) : ;;
  *) echo "!! 警告: 本包针对 5.15.185-tegra (JP6.2.2/R36.5)，当前 $KREL，请确认" ;;
esac

# ---------- 2. 自动识别 ----------
i2c_rd() {  # bus addr reg_hi reg_lo -> 1 byte hex
  i2ctransfer -y "$1" w2@"$2" "$3" "$4" r1 2>/dev/null | tail -1
}
detect_board() {
  # 1) 已绑定（装过本包后）：0x27=FG24, 0x29=FG12
  ls -d /sys/bus/i2c/devices/*-0027 >/dev/null 2>&1 && { echo fg24; return 0; }
  ls -d /sys/bus/i2c/devices/*-0029 >/dev/null 2>&1 && { echo fg12; return 0; }
  # 2) 未绑定（全新机器首装）：读 96712 reg0x0000=0x4e
  for b in /dev/i2c-*; do
    bus="${b#/dev/i2c-}"
    v="$(i2c_rd "$bus" 0x27 0x00 0x00)"
    [ "$(echo "$v" | tr A-F a-f)" = "0x4e" ] && { echo fg24; return 0; }
    v="$(i2c_rd "$bus" 0x29 0x00 0x00)"
    [ "$(echo "$v" | tr A-F a-f)" = "0x4e" ] && { echo fg12; return 0; }
  done
  return 1
}
detect_camera() {
  # 1) 已绑定：0x40 驱动名
  for d in /sys/bus/i2c/devices/*-0040; do
    [ -e "$d/driver" ] || continue
    drv="$(basename "$(readlink -f "$d/driver")")"
    case "$drv" in max9295) echo d457; return 0 ;; max96717) echo d585; return 0 ;; esac
  done
  # 2) 未绑定：读 0x40/0x41 DEV_ID (0xbf=96717/D585, 0x91=9295/D457)
  for b in /dev/i2c-*; do
    bus="${b#/dev/i2c-}"
    for a in 0x40 0x41; do
      v="$(echo "$(i2c_rd "$bus" "$a" 0x00 0x0d)" | tr A-F a-f)"
      case "$v" in 0xbf) echo d585; return 0 ;; 0x91) echo d457; return 0 ;; esac
    done
  done
  return 1
}
[ -n "$BOARD" ]  || BOARD="$(detect_board  || true)"
[ -n "$CAMERA" ] || CAMERA="$(detect_camera || true)"
[ -n "$BOARD" ]  || { BOARD="fg12"; log "未识别到板型，默认 fg12（可用 --board 指定）"; }
[ -n "$CAMERA" ] || { CAMERA="d585"; log "未识别到相机，默认 d585（可用 --camera 指定）"; }
case "$BOARD" in fg12|fg24) ;; *) echo "board 只能是 fg12/fg24"; exit 1 ;; esac
case "$CAMERA" in d585|d457) ;; *) echo "camera 只能是 d585/d457"; exit 1 ;; esac

# 组合 -> dtbo / label
if [ "$BOARD" = "fg24" ] && [ "$CAMERA" = "d585" ]; then DTBO=tegra234-camera-d4xx-overlay-fg24-4ch-d5xx.dtbo; LABEL=fg24d585
elif [ "$BOARD" = "fg24" ] && [ "$CAMERA" = "d457" ]; then DTBO=tegra234-camera-d4xx-overlay-fg24-4ch.dtbo; LABEL=fg24d457
elif [ "$BOARD" = "fg12" ] && [ "$CAMERA" = "d585" ]; then DTBO=tegra234-camera-d4xx-overlay-fg12-4ch-d5xx.dtbo; LABEL=fg12d585
else DTBO=tegra234-camera-d4xx-overlay-fg12-4ch.dtbo; LABEL=fg12d457; fi
log "识别组合: $BOARD + $CAMERA  ->  $DTBO (label $LABEL)"

# ---------- 3. 安装 dtbo ----------
install -m 644 "$HERE/boot/"*.dtbo "$BOOT/"
log "4 个 dtbo 已安装到 $BOOT"

# ---------- 4. 安装模块 ----------
mkdir -p "$DEST"
for f in $(find "$DEST" -name '*.ko' 2>/dev/null); do cp -a "$f" "$f.bak-$STAMP" 2>/dev/null || true; done
cp -a "$HERE/lib/modules/$KREL/updates/." "$DEST/"
find "$DEST" -name '*.ko' -exec chmod 644 {} \;
depmod -a "$KREL"
log "模块已安装并 depmod"

# ---------- 5. 关闭厂商 fzcam ----------
systemctl disable --now fzcam_cfg.service 2>/dev/null || true

# ---------- 6. extlinux 标签 ----------
CONF="$BOOT/extlinux/extlinux.conf"
[ -f "$CONF" ] || { echo "找不到 $CONF"; exit 1; }
cp "$CONF" "$CONF.bak-$STAMP"
FDT="$(awk '/^[[:space:]]*FDT /{print $2; exit}' "$CONF")"
[ -n "$FDT" ] || FDT="/boot/dtb/kernel_tegra234-p3768-0000+p3767-0000-nv.dtb"
APPEND="$(awk '/^[[:space:]]*APPEND /{sub(/^[[:space:]]*APPEND /,"");print; exit}' "$CONF")"

add_label() {  # $1=label  $2=dtbo  $3=desc
  grep -q "^LABEL $1" "$CONF" && return 0
  cat >> "$CONF" <<EOC

LABEL $1
	MENU LABEL RealSense $3
	LINUX /boot/Image
	FDT $FDT
	INITRD /boot/initrd
	APPEND $APPEND
	OVERLAYS $BOOT/$2
EOC
}
add_label fg12d585 tegra234-camera-d4xx-overlay-fg12-4ch-d5xx.dtbo "D585 FG12-4CH"
add_label fg12d457 tegra234-camera-d4xx-overlay-fg12-4ch.dtbo      "D457 FG12-4CH"
add_label fg24d585 tegra234-camera-d4xx-overlay-fg24-4ch-d5xx.dtbo "D585 FG24-4CH"
add_label fg24d457 tegra234-camera-d4xx-overlay-fg24-4ch.dtbo      "D457 FG24-4CH"
sed -i "s/^DEFAULT .*/DEFAULT $LABEL/" "$CONF"
log "extlinux 已写入 4 个标签，DEFAULT=$LABEL"

# ---------- 7. 完成 ----------
log "安装完成，请 reboot 生效"
cat <<EOT
自检:
  grep -E '^DEFAULT|^LABEL' $CONF
  ls /dev/video*            # 期望 video0..video6
  ./verify.sh               # 四流自检（可选）
回滚: sudo sed -i 's/^DEFAULT .*/DEFAULT JetsonIO/' $CONF && sudo reboot
EOT
