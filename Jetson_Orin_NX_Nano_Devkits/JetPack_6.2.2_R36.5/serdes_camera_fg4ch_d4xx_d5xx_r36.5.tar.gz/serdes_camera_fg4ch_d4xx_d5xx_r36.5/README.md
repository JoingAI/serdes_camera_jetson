# FangZhu FG12-4CH / FG24-4CH × RealSense D585 / D457 升级包

一套软件覆盖 **2 种载板 × 2 种相机 = 4 种组合**，全新 Jetson Orin 机器直接升级即可点亮。

| 项 | 值 |
|---|---|
| 平台 | Jetson Orin NX / Orin Nano Devkit（p3768-0000 + p3767-xxxx） |
| 系统 | JetPack **6.2.2** / L4T **R36.5**，内核 **5.15.185-tegra** |
| 相机 | RealSense D585（DS558）/ D457，4 流：Depth / Color / IR / IMU |
| 源码 | build45 `sw/jp6.2.2_r36.5` 分支 **`fg4ch_d4xx_d5xx`**（已 push GitLab） |

## 支持的 4 种组合

| 板卡 | 相机 | 解串器 | 串行器 | overlay | 四流实测 |
|---|---|---|---|---|---|
| FG12-4CH | D585 | 96712@0x29 | MAX96717 | `...-fg12-4ch-d5xx.dtbo` | ✅ 120/120/120/120 |
| FG12-4CH | D457 | 96712@0x29 | MAX9295 | `...-fg12-4ch.dtbo` | ✅ 60/60/60/60 |
| FG24-4CH | D585 | 96712@0x27 | MAX96717 | `...-fg24-4ch-d5xx.dtbo` | ✅ 120/120/120/120 |
| FG24-4CH | D457 | 96712@0x27 | MAX9295 | `...-fg24-4ch.dtbo` | ✅ 60/60/60/60 |

## 包内容

```
install.sh                       # 一键安装（自动识别板型/相机，可 --board/--camera 指定）
verify.sh                        # 四流自检（自动识别 D585/D457 分辨率）
boot/
  tegra234-camera-d4xx-overlay-fg12-4ch-d5xx.dtbo   # FG12 + D585
  tegra234-camera-d4xx-overlay-fg12-4ch.dtbo        # FG12 + D457
  tegra234-camera-d4xx-overlay-fg24-4ch-d5xx.dtbo   # FG24 + D585
  tegra234-camera-d4xx-overlay-fg24-4ch.dtbo        # FG24 + D457
lib/modules/5.15.185-tegra/updates/
  drivers/media/i2c/                     d4xx/max96712/max96717/max96724/max9295/max9296/max929x
  drivers/media/platform/tegra/camera/   tegra-camera.ko
  drivers/video/tegra/host/{nvcsi,vi,capture,isp}/  nvhost-nvcsi(-t194)/vi5/capture/isp5
```

> 只替换 OOT 模块 + 应用 dtbo，**不动 /boot/Image**。所有 .ko 与 5.15.185-tegra 同树编译，vermagic/CRC 匹配。

## 安装

```bash
tar xzf serdes_camera_fg4ch_d4xx_d5xx_r36.5.tar.gz
cd serdes_camera_fg4ch_d4xx_d5xx_r36.5
sudo ./install.sh                  # 自动识别
# 识别不到时:
sudo ./install.sh --board fg24 --camera d457
sudo reboot
```

脚本会：装 4 个 dtbo + 全部模块 → `depmod` → 禁用 `fzcam_cfg` → 写 4 个 extlinux 标签（`fg12d585/fg12d457/fg24d585/fg24d457`）→ 把 DEFAULT 设为识别到的组合。
原厂启动项保留（`DEFAULT JetsonIO` 可回滚），模块与 extlinux 均有 `.bak-时间戳` 备份。

## 上板自检

```bash
sudo ./verify.sh
# 期望：depth/color/ir/imu 各 ≥57/60，RESULT: PASS
```

## 常见坑（已修，勿回退）

1. 原厂 `tegra-camera.ko` 缺 `grey_y16/Z16/Y8I` → 必须用本包同树编译版；
2. 换 `tegra-camera.ko` 必须连带换 `nvhost-*`（符号 CRC 校验）；
3. **Color 字节序**：D585/D457 Color 流在 CSI 线上是 UYVY，`vi5_formats.h` 必须
   `YUYV8_1X16 → T_U8_Y8__V8_Y8`（否则红蓝/色彩错乱）；
4. **D457 必须用 MAX9295**（不是 MAX96717），overlay 写 `max9295_a@40`；
5. 首帧偶发 `discarding frame 0`（EMBED_INCOMPLETE 262144）是启动瞬态，复测即稳。

## 参考

- 案例：`company_data/shared/gmsl/cases/CASE-20261112-y303-fg24-4ch-d585-r36.5.md`
- 源码镜像：`company_data/shared/gmsl/knowledge/02_jetson_platform/realsense_source_repos.md`
