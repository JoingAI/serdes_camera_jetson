#!/bin/bash
# 四流自检：自动识别 D585/D457 分辨率并跑并发取流
set -u
VID=/dev/video
[ -e ${VID}0 ] || { echo "!! 没有 /dev/video0，请先安装并重启"; exit 1; }

fmt() { v4l2-ctl -d ${VID}$1 --get-fmt-video 2>/dev/null; }
h_color=$(fmt 2 | awk '/Width\/Height/{split($3,a,"/");print a[2]}')
h_imu=$(fmt 6 | awk '/Width\/Height/{split($3,a,"/");print a[2]}')
w_imu=$(fmt 6 | awk '/Width\/Height/{split($3,a,"/");print a[1]}')
if [ "${h_color:-0}" = "800" ]; then CAM=D457; else CAM=D585; fi
echo "检测到: $CAM  color=${h_color:-?} imu=${w_imu:-?}x${h_imu:-?}"

dmesg -C >/dev/null 2>&1 || true
# 清理可能残留的取流进程
pkill -f "v4l2-ctl -d /dev/video" 2>/dev/null || true
sleep 1
timeout 25 v4l2-ctl -d ${VID}0 --set-fmt-video=width=1280,height=720,pixelformat="Z16 " --stream-mmap --stream-count=60 >/tmp/.v0 2>&1 & P0=$!
timeout 25 v4l2-ctl -d ${VID}2 --set-fmt-video=width=1280,height=${h_color:-720},pixelformat=YUYV --stream-mmap --stream-count=60 >/tmp/.v2 2>&1 & P2=$!
timeout 25 v4l2-ctl -d ${VID}4 --set-fmt-video=width=1280,height=720,pixelformat="Y8I " --stream-mmap --stream-count=60 >/tmp/.v4 2>&1 & P4=$!
timeout 25 v4l2-ctl -d ${VID}6 --set-fmt-video=width=${w_imu:-256},height=${h_imu:-1},pixelformat=GREY --stream-mmap --stream-count=60 >/tmp/.v6 2>&1 & P6=$!
wait $P0; r0=$?; wait $P2; r2=$?; wait $P4; r4=$?; wait $P6; r6=$?
f0=$(tr -cd '<' </tmp/.v0|wc -c); f2=$(tr -cd '<' </tmp/.v2|wc -c); f4=$(tr -cd '<' </tmp/.v4|wc -c); f6=$(tr -cd '<' </tmp/.v6|wc -c)
echo "frames: depth=$f0 color=$f2 ir=$f4 imu=$f6 /60  (rc $r0/$r2/$r4/$r6)"
errs=$(dmesg | grep -icE 'uncorr_err|err_data 131072')
echo "VI 严重错误(corr/uncorr)=$errs"
[ "$f0" -ge 57 ] && [ "$f2" -ge 57 ] && [ "$f4" -ge 57 ] && [ "$f6" -ge 57 ] && echo "RESULT: PASS" || echo "RESULT: CHECK"
