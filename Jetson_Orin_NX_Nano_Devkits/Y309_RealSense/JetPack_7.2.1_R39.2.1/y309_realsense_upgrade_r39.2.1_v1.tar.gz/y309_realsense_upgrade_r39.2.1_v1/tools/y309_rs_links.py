#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""为 librealsense 创建 /dev/video-rs-<sensor>-<idx> 符号链接。

librealsense 的 MIPI 后端（src/linux/v4l-mipi-logic.cpp）只认
    /dev/video-rs-depth-N / -color-N / -ir-N / -imu-N
这类链接；d4xx 驱动本身在 Y309 上不建它们，所以由本脚本按"格式+分辨率"识别。

只建 capture 节点，**不建 metadata**（建了 md 会卡 16K 空包）。

用法:
    y309_rs_links.py                 # 只为 D585 (0-0030) 建，idx=0
    y309_rs_links.py --group 2-001a  # 指定组
    y309_rs_links.py --all           # 所有 DS5 mux 组（D405 未点亮时不建议）
    y309_rs_links.py --dry-run
"""
import os, re, subprocess, sys, glob

ARGS = sys.argv[1:]
GROUP = None
ALL = "--all" in ARGS
DRY = "--dry-run" in ARGS
if "--group" in ARGS:
    GROUP = ARGS[ARGS.index("--group") + 1]
DEFAULT_GROUP = "0-0030"          # D585 (i2c-0, 0x27, link A)


def sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True).stdout


def list_groups():
    out = sh("v4l2-ctl --list-devices")
    groups, cur, nodes = {}, None, []
    for line in out.splitlines():
        if line and not line.startswith((" ", "\t")) and line.rstrip().endswith(":"):
            if cur:
                groups[cur] = nodes
            cur, nodes = line.rstrip()[:-1], []
        elif re.match(r"\s+/dev/video\d+", line):
            nodes.append(line.strip())
    if cur:
        groups[cur] = nodes
    return groups


def classify(dev):
    out = sh(f"v4l2-ctl -d {dev} --get-fmt-video 2>/dev/null")
    m = re.search(r"Width/Height\s*:\s*(\d+)/(\d+)", out)
    p = re.search(r"Pixel Format\s*:\s*'(.{4})'", out)
    if not m or not p:
        return None
    h, pix = int(m.group(2)), p.group(1).strip()
    if pix == "Z16":
        return "depth"
    if pix == "YUYV":
        return "color"
    if pix == "GREY" and h == 1:
        return "imu"
    if pix == "GREY":
        return "ir"
    return None


def main():
    groups = list_groups()
    made = 0
    idx = 0
    for name, nodes in groups.items():
        m = re.search(r"DS5 mux (\d+-[0-9a-f]{4})", name)
        if not m:
            continue
        gid = m.group(1)
        if GROUP and gid != GROUP:
            continue
        if not GROUP and not ALL and gid != DEFAULT_GROUP:
            continue
        sensors = {}
        for d in nodes:
            k = classify(d)
            if k and k not in sensors:
                sensors[k] = d
        if "depth" not in sensors:
            print(f"  skip {gid}: no depth node")
            continue
        for k, d in sensors.items():
            link = f"/dev/video-rs-{k}-{idx}"
            print(f"  {link} -> {d}")
            if not DRY:
                try:
                    if os.path.islink(link):
                        os.unlink(link)
                    os.symlink(d, link)
                except OSError as e:
                    print(f"    failed: {e}")
        made += 1
        idx += 1
    print(f"done: {made} camera(s)" + (" [dry-run]" if DRY else ""))
    return 0 if made else 1


if __name__ == "__main__":
    sys.exit(main())
