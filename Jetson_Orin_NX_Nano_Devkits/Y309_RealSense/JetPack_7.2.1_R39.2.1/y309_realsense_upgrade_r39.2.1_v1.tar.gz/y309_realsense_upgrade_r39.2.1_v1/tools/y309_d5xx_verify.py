#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Y309 D585(U6/A) + D405(U7/C) 自检

自动按 "vi-output, DS5 mux <i2c>-<addr>" 分组并按格式识别节点，不依赖
/dev/videoN 的固定编号（R39 上节点号跨启动会变）。

用法: sudo ./y309_d5xx_verify.py [每路帧数, 默认 8]
判据: 每路帧数 >= 请求数-1（第 0 帧为空是已知现象）, 且 CSI uncorr_err == 0
"""
import os, re, subprocess, sys

N = int(sys.argv[1]) if len(sys.argv) > 1 else 8
TMP = "/tmp/y309_verify"
os.makedirs(TMP, exist_ok=True)


def sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True)


def list_devices():
    """返回 [(group_name, [video nodes])]"""
    out = sh("v4l2-ctl --list-devices").stdout
    groups, cur, nodes = [], None, []
    for line in out.splitlines():
        if line and not line.startswith((" ", "\t")) and line.rstrip().endswith(":"):
            if cur:
                groups.append((cur, nodes))
            cur, nodes = line.rstrip().rstrip(":"), []
        elif re.match(r"\s+/dev/video\d+", line):
            nodes.append(line.strip())
    if cur:
        groups.append((cur, nodes))
    return groups


def fmt(dev):
    out = sh(f"v4l2-ctl -d {dev} --get-fmt-video").stdout
    w = re.search(r"Width/Height\s*:\s*(\d+)/(\d+)", out)
    p = re.search(r"Pixel Format\s*:\s*'(.{4})'", out)
    if not w or not p:
        return None
    return int(w.group(1)), int(w.group(2)), p.group(1)


def classify(dev):
    f = fmt(dev)
    if not f:
        return None
    w, h, p = f
    p = p.strip()
    if p == "Z16":
        return "depth"
    if p == "YUYV":
        return "rgb"
    if p == "GREY" and h == 1:
        return "imu"
    if p == "GREY":
        return "ir"
    return None


def capture(dev, w, h, pix, name):
    path = os.path.join(TMP, name + ".raw")
    if os.path.exists(path):
        os.unlink(path)
    sh(f'v4l2-ctl -d {dev} --set-fmt-video=width={w},height={h},pixelformat="{pix}"')
    sh(f"timeout {N + 10} v4l2-ctl -d {dev} --stream-mmap --stream-count={N} "
       f"--stream-to={path} >/dev/null 2>&1")
    return path


def stats(path, w, h, bpp):
    fs = w * h * bpp
    if not os.path.exists(path):
        return 0, 0, 0.0, 0.0
    data = open(path, "rb").read()
    frames = len(data) // fs
    valid, mean, std = 0, 0.0, 0.0
    for i in range(1, frames):                     # 第 0 帧为空
        f = data[i * fs:(i + 1) * fs]
        s = f[::97]
        if sum(1 for b in s if b) > len(s) * 0.02:
            valid += 1
            mean = sum(s) / len(s)
            std = (sum((x - mean) ** 2 for x in s) / len(s)) ** 0.5
    return frames, valid, mean, std


def main():
    print("== device groups")
    groups = list_devices()
    plan = {}
    for name, nodes in groups:
        m = re.search(r"DS5 mux (\d+)-([0-9a-f]{4})", name)
        if not m:
            continue
        cam = "d585" if m.group(2) == "0030" else "d405"
        for d in nodes:
            k = classify(d)
            if k:
                plan.setdefault(cam, {})[k] = d
        print(f"  {name}: {len(nodes)} nodes -> {cam}")

    print("\n== stream map")
    for cam in sorted(plan):
        print(f"  {cam}: " + ", ".join(f"{k}={v}" for k, v in sorted(plan[cam].items())))

    print(f"\n== capture ({N} frames each)")
    print("%-6s %-6s %-12s %-6s %-6s %-8s %-8s %s"
          % ("cam", "stream", "node", "frames", "valid", "mean", "std", "result"))
    ok_all = True
    results = []
    for cam in sorted(plan):
        for kind in ("depth", "rgb", "ir"):
            dev = plan[cam].get(kind)
            if not dev:
                print(f"{cam:<6} {kind:<6} {'-':<12} MISSING NODE")
                ok_all = False
                continue
            w, h = (1280, 720)
            pix = {"depth": "Z16 ", "rgb": "YUYV", "ir": "GREY"}[kind]
            p = capture(dev, w, h, pix, f"{cam}_{kind}")
            fr, valid, mean, std = stats(p, w, h, 1 if kind == "ir" else 2)
            good = fr >= N - 1 and valid >= fr - 1
            ok_all = ok_all and good
            results.append((cam, kind, fr, valid))
            print("%-6s %-6s %-12s %-6d %-6d %-8.1f %-8.1f %s"
                  % (cam, kind, dev, fr, valid, mean, std, "PASS" if good else "FAIL"))

    dev = plan.get("d585", {}).get("imu")
    if dev:
        p = capture(dev, 38, 1, "GREY", "d585_imu")
        sz = os.path.getsize(p) if os.path.exists(p) else 0
        print("%-6s %-6s %-12s %-6s %-6s %-8s %-8s bytes=%d"
              % ("d585", "imu", dev, "-", "-", "-", "-", sz))

    errs = int(sh("dmesg | grep -c uncorr_err").stdout.strip() or 0)
    print(f"\nCSI uncorr_err(本次启动累计): {errs}")
    ok_all = ok_all and errs == 0
    print("RESULT:", "PASS" if ok_all else "FAIL")
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
