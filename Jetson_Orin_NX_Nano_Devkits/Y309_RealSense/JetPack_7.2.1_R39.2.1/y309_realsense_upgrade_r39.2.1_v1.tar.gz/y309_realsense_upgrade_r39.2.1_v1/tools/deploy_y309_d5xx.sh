#!/bin/bash
# =============================================================================
# Y309 RealSense（D585 + D405）一键部署
#
#   在 DUT 上执行:
#     sudo ./deploy_y309_d5xx.sh                  # 部署 + 自动重启
#     sudo ./deploy_y309_d5xx.sh --no-reboot      # 只部署，不重启
#     sudo ./deploy_y309_d5xx.sh --pkg /path/pkg  # 指定包目录
#
#   包目录要求（二选一）:
#     A) 官方包解压目录:  boot/ + lib/modules/<ver>/updates/...
#     B) DUT 目录:        /home/nvidia/y309_realsense  (boot/ + modules/)
#
#   部署内容: 14 个 ko + 2 个 dtbo + 启动项 y309-d5xx + /dev/video-rs-* 服务
#   自动备份到 /root/y309_deploy_backup-<时间戳>/
# =============================================================================
set -euo pipefail

KVER="$(uname -r)"
LABEL="y309-d5xx"
DTBO="tegra234-p3767-camera-y309-d5xx.dtbo"
BOARD_DTBO="tegra234-p3767-0000-y309-board.dtbo"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# 允许脚本放在 tools/ 下：自动上溯到包含 boot/ 的包根
if [ ! -d "$HERE/boot" ] && [ -d "$HERE/../boot" ]; then
	HERE="$(cd "$HERE/.." && pwd)"
fi
PKG="$HERE"
NO_REBOOT=0

while [ $# -gt 0 ]; do
	case "$1" in
	--no-reboot) NO_REBOOT=1 ;;
	--pkg) PKG="$2"; shift ;;
	-h|--help) sed -n '2,20p' "$0"; exit 0 ;;
	*) echo "未知参数: $1"; exit 2 ;;
	esac
	shift
done

[ "$(id -u)" -eq 0 ] || { echo "请用 sudo 运行"; exit 1; }
[ "$KVER" = "6.8.12-1021-tegra" ] || \
	echo "[warn] 当前内核 $KVER，包是按 6.8.12-1021-tegra 编译的，模块可能加载失败"

# ---- 定位模块目录（两种布局） ------------------------------------------------
if [ -d "$PKG/lib/modules/$KVER/updates" ]; then
	MODROOT="$PKG/lib/modules/$KVER/updates"
elif [ -d "$PKG/modules/drivers" ]; then
	MODROOT="$PKG/modules"
else
	echo "找不到模块目录："
	echo "  $PKG/lib/modules/$KVER/updates  或  $PKG/modules/drivers"
	exit 1
fi
[ -f "$PKG/boot/$DTBO" ] || { echo "找不到 $PKG/boot/$DTBO"; exit 1; }

B="/root/y309_deploy_backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$B"
cp -a /boot/extlinux/extlinux.conf "$B/" 2>/dev/null || true
[ -f "/boot/$DTBO" ] && cp -a "/boot/$DTBO" "$B/"

echo "[1/6] 安装内核模块 -> /lib/modules/$KVER/updates"
(cd "$MODROOT" && find . -name '*.ko' | sort | while read -r ko; do
	rel="${ko#./}"
	dst="/lib/modules/$KVER/updates/$rel"
	mkdir -p "$(dirname "$dst")"
	[ -f "$dst" ] && cp -a "$dst" "$B/$(echo "$rel" | tr '/' '_').bak"
	install -m 0644 "$ko" "$dst"
	echo "   $rel"
done)
depmod -a "$KVER"

echo "[2/6] 安装 dtbo -> /boot"
install -m 0644 "$PKG/boot/$DTBO" "/boot/$DTBO"
if [ -f "$PKG/boot/$BOARD_DTBO" ] && [ ! -f "/boot/$BOARD_DTBO" ]; then
	install -m 0644 "$PKG/boot/$BOARD_DTBO" "/boot/$BOARD_DTBO"
fi

echo "[3/6] 启动项 $LABEL"
EXT=/boot/extlinux/extlinux.conf
PU="$(grep -oP 'root=PARTUUID=\K[0-9a-f-]+' "$EXT" | head -1)"
if ! grep -q "^LABEL ${LABEL}$" "$EXT"; then
	cat >> "$EXT" <<EOF

LABEL ${LABEL}
      MENU LABEL Y309 RealSense D585(U6/A) + D405(U7/C)
      LINUX /boot/Image
      FDT /boot/dtb/kernel_tegra234-p3768-0000+p3767-0000-nv-super.dtb
      INITRD /boot/initrd
      APPEND \${cbootargs} root=PARTUUID=${PU} rw rootwait rootfstype=ext4 mminit_loglevel=4 console=ttyTCU0,115200 firmware_class.path=/etc/firmware fbcon=map:0 video=efifb:off console=tty0 efi_pstore.pstore_disable=1 pstore.backend=ramoops efi=runtime pci=pcie_bus_perf nvme.use_threaded_interrupts=1 swiotlb=2048
      OVERLAYS /boot/${DTBO},/boot/${BOARD_DTBO}
EOF
fi
sed -i "s/^DEFAULT .*/DEFAULT ${LABEL}/" "$EXT"

echo "[4/6] /dev/video-rs-* 链接服务"
for d in "$HERE/tools" "$PKG/tools"; do
	if [ -f "$d/y309_rs_links.py" ]; then
		install -m 0755 "$d/y309_rs_links.py" /usr/local/bin/y309_rs_links.py
		if [ -f "$d/y309-rs-links.service" ]; then
			install -m 0644 "$d/y309-rs-links.service" /etc/systemd/system/
			systemctl daemon-reload
			systemctl enable y309-rs-links.service >/dev/null 2>&1 || true
			systemctl restart y309-rs-links.service >/dev/null 2>&1 || true
		fi
		break
	fi
done

echo "[5/6] 部署调试工具"
for d in "$HERE/tools" "$PKG/tools"; do
	if [ -f "$d/d405_dbg.sh" ]; then
		install -m 0755 "$d/d405_dbg.sh" /usr/local/bin/d405_dbg
		break
	fi
done

echo "[6/6] 完成，回滚材料: $B"
echo
echo "  当前配置：D585(U6/CSI-A) 4-lane + D405(U7/CSI-C) 2-lane / src port B"
echo "  D585 可点亮；D405 仍未点亮（相机停在 IDLE，需手动调试）"
echo
if [ "$NO_REBOOT" -eq 0 ]; then
	echo "  3 秒后重启（Ctrl-C 取消）..."
	sleep 3
	reboot
else
	echo "  已跳过重启。重启后执行:"
	echo "    sudo d405_dbg regs      # 看寄存器"
	echo "    sudo d405_dbg start     # 手动开流"
	echo "    sudo d405_dbg watch     # 盯 lock/status"
fi
