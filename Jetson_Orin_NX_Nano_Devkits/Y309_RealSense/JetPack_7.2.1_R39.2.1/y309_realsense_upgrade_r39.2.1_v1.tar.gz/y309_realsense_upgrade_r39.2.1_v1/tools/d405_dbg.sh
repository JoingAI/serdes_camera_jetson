#!/bin/bash
# =============================================================================
# D405 手动调试工具（Y309，U7 / i2c-2 / MAX96724@0x27 / MAX9295@0x40 / cam@0x1a）
#
#   sudo d405_dbg regs          # 全部关键寄存器
#   sudo d405_dbg lock          # 链路 lock / VIDEO_LOCK
#   sudo d405_dbg status        # 相机 0x1004(8/16bit) / 0x0404(pixel mode)
#   sudo d405_dbg start [id]    # 手动 START（id: 0=depth 1=rgb 2=imu 4=ir，默认 0）
#   sudo d405_dbg stop  [id]    # 手动 STOP
#   sudo d405_dbg poc on|off    # U7 PoC 0x0319=0x90/0x98
#   sudo d405_dbg watch [秒]    # 每 0.5s 打印 lock/status
#   sudo d405_dbg full          # start + 连续 10s 采样 lock/status
# =============================================================================
set -u
BUS=2
DSER=0x27
SER=0x40
CAM=0x1a

rd() { # bus addr reg16 -> value
	local b=$1 a=$2 h=$3 l=$4
	i2ctransfer -f -y "$b" w2@$a 0x$h 0x$l r1 2>/dev/null
}
rd2() {
	local b=$1 a=$2 h=$3 l=$4
	i2ctransfer -f -y "$b" w2@$a 0x$h 0x$l r2 2>/dev/null
}
wr2() { # bus addr reg16 val16
	i2ctransfer -f -y "$1" w4@$2 0x$3 0x$4 0x$5 0x$6 2>/dev/null
}
p() { printf "  %-22s %s\n" "$1" "$2"; }

cmd=${1:-help}
case "$cmd" in
regs)
	echo "== MAX96724 (i2c-$BUS $DSER)"
	p "DEV_ID 0x000D"  "$(rd $BUS $DSER 00 0d)"
	p "REG6 0x0006"    "$(rd $BUS $DSER 00 06)"
	p "LOCK 0x001A"    "$(rd $BUS $DSER 00 1a)"
	p "VIDEO_LOCK 01DC" "$(rd $BUS $DSER 01 dc)"
	p "PoC 0x0319"     "$(rd $BUS $DSER 03 19)"
	p "0415 rate"      "$(rd $BUS $DSER 04 15)"
	p "08A5/08A6 pol"  "$(rd $BUS $DSER 08 a5) / $(rd $BUS $DSER 08 a6)"
	echo "== MAX9295 ($SER)"
	p "DEV_ID 0x000D"  "$(rd $BUS $SER 00 0d)"
	p "REG2 0x0002"    "$(rd $BUS $SER 00 02)"
	p "0x0013"         "$(rd $BUS $SER 00 13)"
	p "pipeX DT1 0314" "$(rd $BUS $SER 03 14)"
	p "pipeX DT2 0315" "$(rd $BUS $SER 03 15)"
	p "pipeX VC 0309"  "$(rd $BUS $SER 03 09)"
	echo "== Camera ($CAM)"
	p "0x0400 lanes"   "$(rd $BUS $CAM 04 00)"
	p "0x0402 rate"    "$(rd $BUS $CAM 04 02)"
	p "0x0404 pixel"   "$(rd $BUS $CAM 04 04)"
	p "0x1004 status"  "$(rd $BUS $CAM 10 04)"
	;;
lock)
	p "LOCK 0x001A"    "$(rd $BUS $DSER 00 1a)"
	p "VIDEO_LOCK 01DC" "$(rd $BUS $DSER 01 dc)"
	p "ERR 0x0026"     "$(rd $BUS $DSER 00 26)"
	p "ERR 0x0028"     "$(rd $BUS $DSER 00 28)"
	;;
status)
	p "0x1004 (16-bit)" "$(rd2 $BUS $CAM 10 04)"
	p "0x1004 (8-bit)"  "$(rd $BUS $CAM 10 04)"
	p "0x0404 (8-bit)"  "$(rd $BUS $CAM 04 04)"
	p "0x4004"          "$(rd2 $BUS $CAM 40 04)"
	;;
start)
	id=${2:-0}
	case "$id" in 0|1|2|4) ;; *) echo "id 只能是 0/1/2/4"; exit 1;; esac
	printf "START stream %s (0x1000 = 0x%04x)\n" "$id" $((0x200 | id))
	wr2 $BUS $CAM 10 00 0$(( (0x200|id) >> 8 )) $(printf "%02x" $(( (0x200|id) & 0xff )))
	sleep 2
	"$0" status
	"$0" lock
	;;
stop)
	id=${2:-0}
	printf "STOP stream %s\n" "$id"
	wr2 $BUS $CAM 10 00 0$(( (0x100|id) >> 8 )) $(printf "%02x" $(( (0x100|id) & 0xff )))
	;;
poc)
	case "${2:-}" in
	on)  i2ctransfer -f -y $BUS w3@$DSER 0x03 0x19 0x90; echo "PoC ON (0x90)";;
	off) i2ctransfer -f -y $BUS w3@$DSER 0x03 0x19 0x98; echo "PoC OFF (0x98)";;
	*) echo "用法: d405_dbg poc on|off"; exit 1;;
	esac
	sleep 2
	"$0" lock
	;;
watch)
	n=${2:-20}
	for i in $(seq 1 "$n"); do
		printf "%3ds lock=%s video=%s status=%s\n" "$i" \
			"$(rd $BUS $DSER 00 1a)" "$(rd $BUS $DSER 01 dc)" "$(rd $BUS $CAM 10 04)"
		sleep 0.5
	done
	;;
full)
	"$0" start 0 >/dev/null 2>&1
	echo "已 START depth，采样 10s:"
	for i in $(seq 1 20); do
		printf "%3d lock=%s video=%s st16=%s st8=%s\n" "$i" \
			"$(rd $BUS $DSER 00 1a)" "$(rd $BUS $DSER 01 dc)" \
			"$(rd2 $BUS $CAM 10 04)" "$(rd $BUS $CAM 10 04)"
		sleep 0.5
	done
	"$0" stop 0
	;;
*)
	sed -n '2,20p' "$0"
	;;
esac
