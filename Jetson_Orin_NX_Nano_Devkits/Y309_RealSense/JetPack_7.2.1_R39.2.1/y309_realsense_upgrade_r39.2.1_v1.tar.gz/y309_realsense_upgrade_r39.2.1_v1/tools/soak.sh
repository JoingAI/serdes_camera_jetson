#!/bin/bash
# Y309 D585 四路并发长稳：depth + rgb + ir + imu
# 用法: sudo ./soak.sh [秒数，默认 1800]
DUR=${1:-1800}
D=/opt/y309_debug/evidence/soak
rm -rf $D; mkdir -p $D
echo "start $(date -Is) dur=${DUR}s" | tee $D/soak.log

v4l2-ctl -d /dev/video5  --set-fmt-video=width=1280,height=720,pixelformat="Z16 " >/dev/null 2>&1
v4l2-ctl -d /dev/video3  --set-fmt-video=width=1280,height=720,pixelformat=YUYV     >/dev/null 2>&1
v4l2-ctl -d /dev/video1  --set-fmt-video=width=1280,height=720,pixelformat=GREY     >/dev/null 2>&1

dmesg -c > /dev/null 2>&1 || true

for s in "5 depth" "3 rgb" "1 ir" "0 imu"; do
  set -- $s
  v4l2-ctl -d /dev/video$1 --stream-mmap --stream-count=999999 --verbose > $D/$2.log 2>&1 &
  echo "pid $! = $2" | tee -a $D/soak.log
done

sleep $DUR

pkill -TERM -f "v4l2-ctl -d /dev/video" 2>/dev/null
sleep 3
pkill -KILL -f "v4l2-ctl -d /dev/video" 2>/dev/null
sleep 1

{
  echo "end $(date -Is)"
  for n in depth rgb ir imu; do
    f=$(grep -c "dqbuf" $D/$n.log 2>/dev/null)
    e=$(grep -cE "error|Error|timeout|timed out" $D/$n.log 2>/dev/null)
    echo "$n frames=$f errors=$e"
  done
  echo "dmesg uncorr_err: $(dmesg | grep -c uncorr_err)"
  echo "dmesg corr_err:   $(dmesg | grep -c 'corr_err')"
  echo "dmesg timeout:    $(dmesg | grep -c 'request timed out')"
  echo "dmesg PIXEL_INCOMPLETE: $(dmesg | grep -c PIXEL_INCOMPLETE)"
  echo "--- CSI sample"
  dmesg | grep -E "uncorr_err|corr_err|timed out|PIXEL" | tail -10
} | tee -a $D/soak.log
