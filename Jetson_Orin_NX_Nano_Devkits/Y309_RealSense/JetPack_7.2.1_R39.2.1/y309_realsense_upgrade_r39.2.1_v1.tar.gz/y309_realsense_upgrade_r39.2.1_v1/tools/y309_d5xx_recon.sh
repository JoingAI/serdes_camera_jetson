#!/bin/bash
# Y309 D585(U6/CSI-A) + D405(U7/CSI-C) 现场取证脚本
#   sudo ./y309_d5xx_recon.sh
# 输出可直接贴进案例：寄存器 -> 驱动 probe -> media 拓扑 -> 每节点格式
set -u
OUT=${1:-/tmp/y309_d5xx_recon}
mkdir -p "$OUT"

sec() { echo; echo "==================== $* ===================="; }

sec "0. 启动项 / 内核"
cat /proc/device-tree/model 2>/dev/null; echo
uname -a
cat /proc/version
grep -E "^DEFAULT|^LABEL|OVERLAYS" /boot/extlinux/extlinux.conf | tail -12

sec "1. 两颗 MAX96724：身份 / link lock / PoC"
for b in 0 2; do
  echo "--- i2c-$b"
  echo -n "  DEV_ID(0x000D) = "; i2ctransfer -f -y $b w2@0x27 0x00 0x0d r1 2>&1
  echo -n "  REG6  (0x0006) = "; i2ctransfer -f -y $b w2@0x27 0x00 0x06 r1 2>&1
  echo -n "  0x001A lock    = "; i2ctransfer -f -y $b w2@0x27 0x00 0x1a r1 2>&1
  echo -n "  0x0319 PoC     = "; i2ctransfer -f -y $b w2@0x27 0x03 0x19 r1 2>&1
  for link in 0a 0b 0c; do
    echo -n "  link$link         = "; i2ctransfer -f -y $b w2@0x27 0x00 0x$link r1 2>&1
  done
  echo -n "  ser 0x40 DEV_ID= "; i2ctransfer -f -y $b w2@0x40 0x00 0x0d r1 2>&1
  echo "  i2cdetect:"; i2cdetect -y -r $b | tail -5 | sed 's/^/    /'
done

sec "2. 驱动 probe"
dmesg | grep -iE "d4xx|max96724|max96717|max9295|tegra-camera|nvcsi|ds5" | tail -80

sec "3. 视频节点"
ls -la /dev/video* 2>/dev/null
echo "--- video-rs links"
ls -la /dev/video-rs-* 2>/dev/null
echo "--- v4l2-ctl --list-devices"
v4l2-ctl --list-devices 2>/dev/null

sec "4. media 拓扑（摘要）"
media-ctl -p 2>/dev/null | head -120

sec "5. 每个 video 节点的格式"
for v in /dev/video*; do
  [ -c "$v" ] || continue
  echo "--- $v"
  v4l2-ctl -d "$v" --list-formats-ext 2>/dev/null | head -12
done

sec "6. CSI 错误计数"
dmesg | grep -icE "uncorr_err|PIXEL_INCOMPLETE|request timed out"

echo
echo "取证输出已保存到 $OUT"
{
  dmesg | tail -300
} > "$OUT/dmesg_tail.log" 2>/dev/null
for b in 0 2; do i2cdetect -y -r $b > "$OUT/i2cdetect_$b.log" 2>/dev/null; done
v4l2-ctl --list-devices > "$OUT/v4l2_devices.log" 2>/dev/null
echo "RESULT: recon done"
