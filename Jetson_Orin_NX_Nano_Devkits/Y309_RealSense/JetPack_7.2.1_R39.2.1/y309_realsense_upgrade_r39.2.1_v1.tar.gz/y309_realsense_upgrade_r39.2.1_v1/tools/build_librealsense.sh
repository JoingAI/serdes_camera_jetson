#!/bin/bash
# 在 DUT 上重新编译并安装 librealsense（v2.59.1，MIPI 后端）
#   用法: sudo ./build_librealsense.sh [源码目录, 默认 /opt/y309_debug/librealsense/librealsense]
set -euo pipefail
SRC=${1:-/opt/y309_debug/librealsense/librealsense}
JOBS=${JOBS:-$(($(nproc)-1))}

[ -f "$SRC/CMakeLists.txt" ] || { echo "找不到 librealsense 源码: $SRC"; exit 1; }
echo "[*] 源码: $SRC"
grep -E "define RS2_API_(MAJOR|MINOR|PATCH)_VERSION" "$SRC/include/librealsense2/rs.h" | sed 's/^/    /'

echo "[*] 依赖检查"
for p in cmake g++; do command -v $p >/dev/null || { echo "缺少 $p"; exit 1; }; done

mkdir -p "$SRC/build"
cd "$SRC/build"
echo "[*] cmake 配置"
cmake .. \
  -DBUILD_EXAMPLES=true \
  -DCMAKE_BUILD_TYPE=Release \
  -DFORCE_RSUSB_BACKEND=false \
  -DBUILD_WITH_CUDA=false \
  -DBUILD_PYTHON_BINDINGS=false

echo "[*] 编译 (-j$JOBS)"
make -j"$JOBS"

echo "[*] 安装 + ldconfig"
make install
ldconfig

echo "[*] 版本"
rs-enumerate-devices --version 2>/dev/null | head -3 || true
echo "完成。二进制在 /usr/local/bin, 库在 /usr/local/lib"
