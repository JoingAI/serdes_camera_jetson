#!/bin/bash
# ---------------------------------------------------------------------------
# serdes_camera_y309_d585_d405  installer
#   Y309 (Orin NX 16GB + 2x MAX96724) RealSense D585 (U6/CSI-A) + D405 (U7/CSI-C)
#
# 用法:
#   sudo ./install.sh                # 安装模块 + dtbo + 启动项, 不改 DEFAULT
#   sudo ./install.sh --set-default  # 同时把 DEFAULT 切到 y309-d5xx
#   sudo ./install.sh --modules-only # 只装模块 (调试用)
#   sudo ./install.sh --dtbo-only    # 只装 dtbo
#   sudo ./install.sh --dry-run
#
# 安装前会备份将被覆盖的文件到 /root/y309_d5xx_backup-<时间戳>/
# ---------------------------------------------------------------------------
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KVER="$(uname -r)"
KMOD="/lib/modules/${KVER}"
DTBO="tegra234-p3767-camera-y309-d5xx.dtbo"
BOARD_DTBO="tegra234-p3767-0000-y309-board.dtbo"
LABEL="y309-d5xx"
BACKUP="/root/y309_d5xx_backup-$(date +%Y%m%d-%H%M%S)"
DRY=0; SET_DEFAULT=0; MODULES_ONLY=0; DTBO_ONLY=0

for a in "$@"; do
	case "$a" in
	--dry-run) DRY=1 ;;
	--set-default) SET_DEFAULT=1 ;;
	--modules-only) MODULES_ONLY=1 ;;
	--dtbo-only) DTBO_ONLY=1 ;;
	-h|--help) sed -n '2,20p' "$0"; exit 0 ;;
	*) echo "unknown option: $a"; exit 2 ;;
	esac
done

run() { if [ $DRY -eq 1 ]; then echo "  [dry] $*"; else "$@"; fi; }
say() { echo "[*] $*"; }

[ "$(id -u)" -eq 0 ] || { echo "请用 sudo 运行"; exit 1; }
if [ -f "${HERE}/MD5SUMS" ]; then
	say "校验包完整性"
	( cd "$HERE" && md5sum -c MD5SUMS --quiet ) || { echo "MD5 校验失败"; exit 1; }
fi

mkdir -p "$BACKUP"
say "备份目录: $BACKUP"

# ---- 模块 ----------------------------------------------------------------
if [ $DTBO_ONLY -eq 0 ]; then
	say "安装内核模块 (vermagic: ${KVER})"
	pushd "${HERE}/lib/modules/${KVER}/updates" >/dev/null
	find . -name '*.ko' | while read -r ko; do
		dst="${KMOD}/updates/${ko#./}"
		mkdir -p "$(dirname "$dst")"
		[ -f "$dst" ] && cp -a "$dst" "$BACKUP/$(echo "$dst" | tr '/' '_').bak"
		run install -m 0644 -D "$ko" "$dst"
		echo "    $dst"
	done
	popd >/dev/null
	say "depmod -a"
	run depmod -a "$KVER"
fi

# ---- dtbo ----------------------------------------------------------------
if [ $MODULES_ONLY -eq 0 ]; then
	say "安装 dtbo"
	[ -f "/boot/${DTBO}" ] && cp -a "/boot/${DTBO}" "$BACKUP/${DTBO}.bak"
	run install -m 0644 "${HERE}/boot/${DTBO}" "/boot/${DTBO}"
	if [ -f "${HERE}/boot/${BOARD_DTBO}" ] && [ ! -f "/boot/${BOARD_DTBO}" ]; then
		say "板级 dtbo 不存在，补装 ${BOARD_DTBO}"
		run install -m 0644 "${HERE}/boot/${BOARD_DTBO}" "/boot/${BOARD_DTBO}"
	fi
fi

# ---- 启动项 --------------------------------------------------------------
if [ $MODULES_ONLY -eq 0 ]; then
	EXT=/boot/extlinux/extlinux.conf
	say "处理启动项 ${LABEL}"
	cp -a "$EXT" "$BACKUP/extlinux.conf.bak"
	if grep -q "^LABEL ${LABEL}$" "$EXT"; then
		say "启动项已存在, 跳过"
	else
		if [ $DRY -eq 1 ]; then
			echo "  [dry] append LABEL ${LABEL}"
		else
			cat >> "$EXT" <<EOF

LABEL ${LABEL}
      MENU LABEL Y309 RealSense D585(U6/A) + D405(U7/C)
      LINUX /boot/Image
      FDT /boot/dtb/kernel_tegra234-p3768-0000+p3767-0000-nv-super.dtb
      INITRD /boot/initrd
      APPEND \${cbootargs} root=PARTUUID=$(grep -oP 'root=PARTUUID=\K[0-9a-f-]+' "$EXT" | head -1) rw rootwait rootfstype=ext4 mminit_loglevel=4 console=ttyTCU0,115200 firmware_class.path=/etc/firmware fbcon=map:0 video=efifb:off console=tty0 efi_pstore.pstore_disable=1 pstore.backend=ramoops efi=runtime pci=pcie_bus_perf nvme.use_threaded_interrupts=1 swiotlb=2048
      OVERLAYS /boot/${DTBO},/boot/${BOARD_DTBO}
EOF
		fi
	fi
	if [ $SET_DEFAULT -eq 1 ]; then
		say "DEFAULT -> ${LABEL}"
		run sed -i "s/^DEFAULT .*/DEFAULT ${LABEL}/" "$EXT"
	fi
fi

echo
say "完成。回滚材料在 $BACKUP"
echo "  下一步: sudo reboot   (启动菜单选 ${LABEL} 或改 DEFAULT)"
echo "  自检:   sudo ./tools/y309_d5xx_verify.py 8"
