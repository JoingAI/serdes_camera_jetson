# y309_realsense_upgrade_r39.2.1_v1

Y309 整机（Orin NX 16GB + 2×MAX96724）RealSense **D585**（U6/LinkA）+
**D405**（U7/LinkA）的升级固件包（**纯二进制：dtbo + 完整 ko + 工具，不含源码**）。
JetPack 7.2.1 / L4T **R39.2.1**，内核 `6.8.12-1021-tegra`。

> 状态（2026-11-21）：
> - **D585：Depth/RGB/IR 三路 1280x720@30，30 min 并发 29.92 fps，CSI 错误 0；IMU 100 Hz（帧截断待修）。**
> - **D405：probe/I2C/GMSL link 正常，但相机拒绝开流（`VIDEO_LOCK=0`），未点亮。**

## 包内容（14 个模块）

```
boot/
  tegra234-p3767-camera-y309-d5xx.dtbo     双相机 overlay
  tegra234-p3767-0000-y309-board.dtbo      Y309 板级 overlay（缺失时补装）
lib/modules/6.8.12-1021-tegra/updates/
  drivers/media/i2c/{d4xx,fzcam,max96724,max96717,max9295,max9296,max96712,max929x}.ko
  drivers/media/platform/tegra/camera/{tegra-camera,tegra-capture-isp}.ko
  drivers/video/tegra/host/{nvcsi,vi,capture,isp}/nvhost-*.ko
tools/  y309_d5xx_verify.py / y309_rs_links.py / soak.sh / recon.sh /
        build_librealsense.sh / y309-rs-links.service
install.sh   VERSION   MD5SUMS   README.md
```

## 安装

```bash
tar xzf y309_realsense_upgrade_r39.2.1_v1.tar.gz
cd y309_realsense_upgrade_r39.2.1_v1
sudo ./install.sh --dry-run
sudo ./install.sh --set-default     # 安装并切 DEFAULT 到 y309-d5xx
sudo reboot
```

安装前自动备份到 `/root/y309_d5xx_backup-<时间戳>/`；`MD5SUMS` 校验失败直接退出。

## 自检与 viewer

```bash
sudo ./tools/y309_d5xx_verify.py 8      # 自动识别节点，逐流出图
sudo ./tools/y309_rs_links.py           # 建 /dev/video-rs-*（librealsense 必需）
rs-enumerate-devices -s                 # RealSense D585 Prototype / GMSL
rs-record -f /tmp/t.db3 -t 5
DISPLAY=:0 realsense-viewer
```

`y309-rs-links.service` 已包含，可 `systemctl enable --now` 开机自动建链接。

## 已知问题

1. **D405 未点亮**：相机拒绝 `START_STREAM`（`0x1004=0x0100`）、`VIDEO_LOCK=0`、
   大量寄存器返回 `0xCAFE` 哨兵；详见知识库案例 CASE-20261121 §5.6。
2. **IMU 截断**：38x1 / 64 B 每帧（实际应为 38x32 / 2048 B）。
3. **换相机后**：`sudo rmmod d4xx && sudo modprobe d4xx`。
4. 包替换了 `tegra-camera.ko`，同时包含同批构建的 `fzcam.ko`；`y309-obc` 启动项
   使用独立的 `g300.ko`，升级后若要用 Orbbec 配置需另装其模块集。

## 版本

| 项 | 值 |
|---|---|
| 包 | y309_realsense_upgrade r39.2.1 v1（2026-11-21） |
| 分支 | build45 `y309_d4xx`（已推送 GitLab） |
| d4xx | 1.0.7.4 |
| 校验 | `MD5SUMS` + 同名 `.sha256` |
